# Overleaf upload package

Upload the zipped folder to the existing project on latex.ustc.edu.cn
(New Project -> Upload Project, or upload the files into the existing project).

## Main document

After upload, open **Menu -> Main document** and select:

- `paper/main_elsevier.tex` for the Ultramicroscopy/Elsevier preprint layout
  (line numbers, `elsarticle-num`, keywords, declarations), or
- `paper/main.tex` for the plain 10-pt article version.

Set the compiler to **pdfLaTeX**. The Elsevier class and bibliography style are
included in `paper/` (`elsarticle.cls`, `elsarticle-num.bst`). If citations show
as `[?]`, run **Recompile** once more or choose **BibTeX** in the compile menu;
the `.bbl` files are also included as a fallback.

The supplementary information has its own root document: set
`paper/si.tex` as the main document and recompile.

## What is in the package

```
paper/main_elsevier.tex      Elsevier preprint (recommended submission source)
paper/main.tex               plain article version
paper/si.tex                 Supplementary Information
paper/numbers.tex            generated result macros
paper/real_numbers.tex       real-data macros
paper/fmd_numbers.tex        FMD macros
paper/references.bib         bibliography
paper/tables/                generated tables
figures/                     main-text figure PDFs
docs/                        cover letter, highlights, author template, checklist
```

## Before submission

The manuscript still contains author/affiliation and declaration placeholders
in `paper/main_elsevier.tex`:

- `[Author One]`, `[Author Two]`, `[Department, Institution]`, emails, ORCID
- CRediT, competing-interest, funding, and generative-AI declarations

Fill these from `docs/AUTHOR_INFO.md`. The article version `paper/main.tex` has
an empty author block by design.

Current build: main article 12 pages, SI 10 pages, Elsevier preprint 22 pages.
This package was rebuilt on 2026-11-08 after the final consistency edits
(150-field FMD numbers, denoising scope, Airy-PSF caveat, per-microscope
baseline tuning).
